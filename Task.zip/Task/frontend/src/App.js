import 'bootstrap/dist/css/bootstrap.min.css'
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Employee from './Employee';
import CreateEmployee from './CreateEmployee';
import UpdateEmp from './UpdateEmp';

function App() {
  return (
    <div className="App">
     <BrowserRouter>
     <Routes>
      <Route path='/' element={<Employee></Employee>}></Route>
      <Route path='/create' element={<CreateEmployee></CreateEmployee>}></Route>
      <Route path='/update/:id' element={<UpdateEmp></UpdateEmp>}></Route>


     </Routes>
     </BrowserRouter>
    </div>
  );
}

export default App;
